---
name: Precision Surface QC
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#3f4850'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#707881'
  outline-variant: '#bfc7d2'
  surface-tint: '#006398'
  primary: '#006194'
  on-primary: '#ffffff'
  primary-container: '#007bb9'
  on-primary-container: '#fdfcff'
  inverse-primary: '#93ccff'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#0051d5'
  on-tertiary: '#ffffff'
  tertiary-container: '#316bf3'
  on-tertiary-container: '#fefcff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#cce5ff'
  primary-fixed-dim: '#93ccff'
  on-primary-fixed: '#001d31'
  on-primary-fixed-variant: '#004b73'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#dbe1ff'
  tertiary-fixed-dim: '#b4c5ff'
  on-tertiary-fixed: '#00174b'
  on-tertiary-fixed-variant: '#003ea8'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.005em
  headline-sm:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0em
  label-mono-lg:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: -0.01em
  label-mono-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0em
  label-mono-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.02em
  label-ui:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.25rem
  margin: 1rem
  margin-desktop: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

This design system targets high-throughput manufacturing, assembly line verification, and automated optical inspection (AOI) environments. The users are quality engineers, line operators, and plant supervisors who need instantaneous clarity without visual friction.

The style is **Industrial Functionalism**: clean, hyper-structured, high-contrast, and strictly utilitarian. It eliminates all decorative gradients, skeuomorphic textures, and ambient illustrations in favor of structural clarity, precise visual density, and rapid status parsing. High-speed anomaly verification requires decisive feedback; cognitive overhead is minimized through purposeful typography, crisp 1px partition lines, and unambiguous status tokens.

## Colors

The palette is engineered for optical clarity under demanding factory floor lighting conditions. 

- **Surfaces**: Canvas backgrounds alternate between pure stark white (`#FFFFFF`) for operational cards and technical inspectors, and calibrated slate tints (`#F8FAFC`, `#F1F5F9`) for peripheral structural panels and toolbars.
- **Text & Structure**: Primary data, telemetry labels, and headings sit at dark navy slate (`#0F172A`), supported by secondary body and meta information at `#334155` and `#64748B`. Structural separation is enforced via razor-sharp `#E2E8F0` and `#CBD5E1` dividing borders.
- **Accents**: Precision technical blues (`#0284C7`, `#2563EB`) handle active system states, focal crosshairs, bounding box triggers, and primary telemetry calls-to-action.
- **Status Tokens (State Triplets)**:
  - **PASS / Nominal**: Text and stroke `#16A34A`, tinted background `#DCFCE7`.
  - **FAIL / Defect**: Text and stroke `#DC2626`, tinted background `#FEE2E2`.
  - **REVIEW / Alert**: Text and stroke `#D97706`, tinted background `#FEF3C7`.

## Typography

Typography prioritizes rapid legibility, data alignment, and contextual hierarchy:

- **Primary Interface (Inter)**: Applied across all operational instructions, high-level system summaries, table headers, and form labels. Provides an unobtrusive, highly legible foundation.
- **Machine Data & Identification (JetBrains Mono)**: Applied strictly to unit serial numbers, part UUIDs, camera coordinates (X/Y/Z), confidence scores, defect tolerances, and timestamp telemetry. The monospaced cadence guarantees tabular numeric stability during live sensor updates.
- All numbers, telemetry values, and decimal metrics must utilize tabular figures (`tnum`) to eliminate column horizontal jitter during continuous camera sampling.

## Layout & Spacing

The layout is built on a high-density, rigid 12-column layout designed to maximize visible tooling and analytical camera viewport area:

- **Desktop (>= 1280px)**: 12-column layout with 20px gutters and 24px canvas margins. Viewports prioritize dual-pane arrangements: fixed-aspect defect stream (minimum 65% width) paired with a persistent 35% inspection inspection-log panel.
- **Tablet / Industrial Terminals (768px - 1279px)**: 8-column layout with 16px gutters and 16px margins. Telemetry panels collapse beneath the live viewport or into segmented sliding tabs.
- **Mobile Handheld Diagnostic Devices (< 768px)**: 4-column layout with 12px gutters and 16px margins. Live frame is pinned top with stacked action buttons below for thumb reachability.
- Internal component density is compact (`space-xs` through `space-md`) to ensure zero-scroll visibility for core pass/fail metrics.

## Elevation & Depth

Visual separation relies strictly on **low-contrast structural borders and tonal layering**. Soft ambient drop shadows and blur effects are explicitly omitted to preserve high-contrast visibility and rendering performance on low-spec industrial displays.

- **Tonal Layers**: The canvas uses `#F8FAFC`. Secondary containers and card panels sit atop it in pure `#FFFFFF`. Hover states and contextual toolbars utilize `#F1F5F9`.
- **Crisp Structural Borders**: Every card, module, panel split, and data table cell uses a single, solid 1px border (`#E2E8F0`). Under active inspection or focus, borders step up to `#0284C7` (2px width where necessary).
- **Z-Index Layering (Modals / Overlays)**: In the rare case of image zoom loupes or critical emergency stops, overlay windows use an opaque white background surrounded by a solid 1px `#CBD5E1` border and a single, hard-edged functional floor shadow (`0 4px 0 0 rgba(15, 23, 42, 0.05)`).

## Shapes

The design system enforces a **Soft (Level 1)** geometric standard. Subtle corner rounding softens the rigid technical layout without compromising the utilitarian, hardware-adjacent feel:

- **Base Components**: Inputs, buttons, chips, and small controls use a radius of `0.25rem` (4px).
- **Surface Containers**: Cards, visual inspection panels, and diagnostic viewports use `rounded-lg` (`0.5rem` / 8px).
- **Modals & Drawers**: Structural overlays use `rounded-xl` (`0.75rem` / 12px).
- Bounding boxes and defect markers on live camera streams are strictly hard-cornered (`0px` radius) with 1px or 2px crosshairs to avoid masking edge flaws.

## Components

- **Buttons**:
  - *Primary*: Flat `#0284C7` fill with stark white text, 1px border of `#0284C7`. Active: `#0369A1`.
  - *Secondary / Utility*: Stark white background, `#E2E8F0` 1px border, `#0F172A` text. Hover: `#F8FAFC`.
  - *Pass/Fail Direct Action*: Full-width tactile action triggers. Pass button uses `#16A34A` background; Fail button uses `#DC2626` background. Both use white high-contrast bold typography.
- **Status Badges & Chips**:
  - Encased in 1px solid borders matching their thematic hue.
  - *Pass*: Background `#DCFCE7`, text `#16A34A`, border `#86EFAC`. Text in uppercase `label-mono-sm`.
  - *Fail*: Background `#FEE2E2`, text `#DC2626`, border `#FCA5A5`. Text in uppercase `label-mono-sm`.
  - *Review*: Background `#FEF3C7`, text `#D97706`, border `#FCD34D`. Text in uppercase `label-mono-sm`.
- **Input Fields & Numeric Adjusters**:
  - Neutral `#FFFFFF` fill with 1px `#E2E8F0` border. Text in `JetBrains Mono` for threshold values, coordinates, and tolerances.
  - Focus state shifts border directly to `#0284C7` with no halo or glow effect.
- **Checkboxes & Radios**:
  - Sharp 4px radius for checkboxes, full circle for radios.
  - Unchecked: `#FFFFFF` fill with 1px `#CBD5E1` outline.
  - Checked: Solid `#0F172A` or `#0284C7` fill with white indicator icon.
- **Data Tables & Feed Lists**:
  - Striped or bordered rows using 1px `#F1F5F9` dividers. Row height fixed at 36px for high density.
  - Headers set in `label-ui` uppercase slate `#64748B`. Numeric columns strictly right-aligned using `JetBrains Mono`.
- **Inspection Cards**:
  - White surface background, 1px `#E2E8F0` perimeter border. Divided by an integrated internal header strip showing unit timestamp, camera feed ID, and automated confidence score.
- **Bounding Box Overlay**:
  - SVG/Canvas overlay component for real-time visual feeds. 1.5px non-anti-aliased vector stroke with floating status pill anchored to top-left coordinate corner.
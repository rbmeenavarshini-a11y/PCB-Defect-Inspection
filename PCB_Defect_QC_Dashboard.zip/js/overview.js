/**
 * AOI VisionQC - Overview Dashboard Controller
 * Handles live KPI summary cards, Defect Pareto distribution,
 * and live Recent Inspections table rendering.
 */

const api = window.api;

document.addEventListener('DOMContentLoaded', () => {
  setupNavigation();
  renderDashboard();
});

function setupNavigation() {
  const isRootPage = window.location.pathname.endsWith('home.html') || 
                     window.location.pathname.endsWith('index.html') ||
                     !window.location.pathname.includes('quality_control_overview');

  const prefix = isRootPage ? './' : '../';

  const navLinks = {
    'Overview': isRootPage ? './home.html' : '../home.html',
    'New Inspection': prefix + 'new_inspection_defect_analysis/code.html',
    'Inspection History': prefix + 'inspection_history_records_reports/code.html',
    'Analytics': prefix + 'quality_analytics_trends/code.html',
    'System Status': prefix + 'system_status_diagnostics/code.html'
  };

  document.querySelectorAll('aside nav a').forEach(link => {
    const text = link.querySelector('span:last-child')?.textContent?.trim();
    if (navLinks[text]) {
      link.href = navLinks[text];
    }
  });

  // Wire "Quick Scan" and "New Inspection" CTA buttons
  document.querySelectorAll('button').forEach(btn => {
    if (btn.textContent.includes('Quick Scan') || btn.textContent.includes('New Inspection')) {
      btn.addEventListener('click', () => {
        window.location.href = prefix + 'new_inspection_defect_analysis/code.html';
      });
    }
  });
}

function renderDashboard() {
  const summary = api.getAnalyticsSummary();
  if (!summary) return;

  // 1. Update 4 KPI Metric Cards
  const kpiCards = document.querySelectorAll('section.grid > div.bg-surface-container-lowest');
  if (kpiCards.length >= 4) {
    // Card 1: Total Inspections
    const totalVal = kpiCards[0].querySelector('.font-label-mono-lg');
    if (totalVal) totalVal.textContent = (summary.total || 0).toLocaleString();

    // Card 2: Passed
    const passVal = kpiCards[1].querySelector('.font-label-mono-lg');
    if (passVal) passVal.textContent = (summary.passed || 0).toLocaleString();

    // Card 3: Failed
    const failVal = kpiCards[2].querySelector('.font-label-mono-lg');
    const failRate = kpiCards[2].querySelector('.font-label-mono-sm.text-\\[\\#DC2626\\]');
    if (failVal) failVal.textContent = (summary.failed || 0).toLocaleString();
    if (failRate) failRate.textContent = `${summary.defectRate}% Defect Rate`;

    // Card 4: Needs Review
    const reviewVal = kpiCards[3].querySelector('.font-label-mono-lg');
    if (reviewVal) reviewVal.textContent = (summary.review || 0).toLocaleString();
  }

  // 2. Update Defect Distribution Bars (6 PCB Classes)
  renderDefectDistribution(summary.classCounts);

  // 3. Update Recent Inspections Table
  renderRecentTable(summary.recent);
}

function renderDefectDistribution(counts) {
  const container = document.querySelector('section .lg\\:col-span-5 .p-space-lg');
  if (!container || !counts) return;

  const totalDefects = Object.values(counts).reduce((a, b) => a + b, 0) || 1;
  const totalBadge = document.querySelector('section .lg\\:col-span-5 span.font-label-mono-sm.px-2');
  if (totalBadge) totalBadge.textContent = `${totalDefects} Total`;

  const classes = [
    { key: 'missing_hole', label: 'Missing Hole', color: '#DC2626' },
    { key: 'short', label: 'Short Circuit', color: '#DC2626' },
    { key: 'mouse_bite', label: 'Mouse Bite', color: '#006194' },
    { key: 'spur', label: 'Spur', color: '#D97706' },
    { key: 'open_circuit', label: 'Open Circuit', color: '#DC2626' },
    { key: 'spurious_copper', label: 'Spurious Copper', color: '#565e74' }
  ];

  container.innerHTML = '';
  classes.forEach(c => {
    const count = counts[c.key] || 0;
    const pct = ((count / totalDefects) * 100).toFixed(1);

    const barEl = document.createElement('div');
    barEl.className = 'flex flex-col gap-1';
    barEl.innerHTML = `
      <div class="flex justify-between items-center font-label-ui text-label-ui">
        <span class="font-semibold text-on-surface flex items-center gap-space-xs">
          <span class="w-2 h-2 rounded-full" style="background-color: ${c.color}"></span>
          ${c.label}
        </span>
        <div class="flex items-center gap-space-sm font-label-mono-sm text-label-mono-sm">
          <span class="text-on-surface font-semibold">${count} incidents</span>
          <span class="text-secondary">(${pct}%)</span>
        </div>
      </div>
      <div class="w-full bg-surface-container h-3 rounded overflow-hidden flex">
        <div class="h-full rounded" style="width: ${Math.max(pct, count > 0 ? 4 : 0)}%; background-color: ${c.color}"></div>
      </div>
    `;
    container.appendChild(barEl);
  });
}

function renderRecentTable(records) {
  const tbody = document.querySelector('section .lg\\:col-span-7 table tbody');
  if (!tbody || !records) return;

  tbody.innerHTML = '';
  records.slice(0, 8).forEach(rec => {
    const row = document.createElement('tr');
    row.className = 'hover:bg-surface-container-low transition-colors duration-150';

    const isPass = rec.status === 'PASS';
    const isFail = rec.status === 'FAIL';
    const badgeBg = isPass ? 'bg-[#DCFCE7] text-[#16A34A] border-[#86EFAC]' :
                    isFail ? 'bg-[#FEE2E2] text-[#DC2626] border-[#FCA5A5]' :
                    'bg-[#FEF3C7] text-[#D97706] border-[#FCD34D]';

    const defectsSummary = !rec.defects || rec.defects.length === 0 
      ? 'None' 
      : `${rec.defects.length} (${rec.defects.map(d => d.display_name).join(', ')})`;

    const dateStr = rec.timestamp ? new Date(rec.timestamp).toLocaleTimeString() : 'Recently';

    row.innerHTML = `
      <td class="py-2.5 px-space-md font-label-mono-sm text-label-mono-sm font-semibold text-primary">${rec.inspection_id}</td>
      <td class="py-2.5 px-space-md font-label-mono-sm text-label-mono-sm text-on-surface">${dateStr}</td>
      <td class="py-2.5 px-space-md font-label-mono-sm text-label-mono-sm text-secondary">${rec.batch_number || 'SMT-2026-LN04'}</td>
      <td class="py-2.5 px-space-md text-on-surface ${isFail ? 'text-error font-medium' : ''}">${defectsSummary}</td>
      <td class="py-2.5 px-space-md">
        <span class="inline-flex items-center px-1.5 py-0.5 rounded border ${badgeBg} font-label-mono-sm text-label-mono-sm font-semibold">${rec.status}</span>
      </td>
      <td class="py-2.5 px-space-md text-right">
        <a class="font-label-ui text-label-ui text-primary font-medium hover:underline inline-flex items-center gap-0.5 cursor-pointer" 
           href="../new_inspection_defect_analysis/code.html">
          <span>View Details</span>
          <span class="material-symbols-outlined text-[14px]">chevron_right</span>
        </a>
      </td>
    `;
    tbody.appendChild(row);
  });
}

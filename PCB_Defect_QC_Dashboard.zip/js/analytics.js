/**
 * AOI VisionQC - Quality Analytics & Trends Controller
 * Dynamically computes First Pass Yield (FPY), Overall Defect Rate,
 * and Pareto frequency breakdown for the 6 PCB defect classes.
 */

const api = window.api;

document.addEventListener('DOMContentLoaded', () => {
  setupNavigation();
  renderAnalytics();
});

function setupNavigation() {
  const navLinks = {
    'Overview': '../home.html',
    'New Inspection': '../new_inspection_defect_analysis/code.html',
    'Inspection History': '../inspection_history_records_reports/code.html',
    'Analytics': '../quality_analytics_trends/code.html',
    'System Status': '../system_status_diagnostics/code.html'
  };

  document.querySelectorAll('aside nav a').forEach(link => {
    const text = link.querySelector('span:last-child')?.textContent?.trim();
    if (navLinks[text]) {
      link.href = navLinks[text];
    }
  });

  document.querySelectorAll('button').forEach(btn => {
    if (btn.textContent.includes('Quick Scan')) {
      btn.addEventListener('click', () => {
        window.location.href = '../new_inspection_defect_analysis/code.html';
      });
    }
  });
}

function renderAnalytics() {
  const summary = api.getAnalyticsSummary();
  if (!summary) return;

  // 1. Update 4 KPI Cards
  const kpiCards = document.querySelectorAll('.grid.grid-cols-1.sm\\:grid-cols-2.lg\\:grid-cols-4 > div');
  if (kpiCards.length >= 4) {
    // Total Inspections
    const totalEl = kpiCards[0].querySelector('.font-label-mono-lg');
    if (totalEl) totalEl.textContent = (summary.total || 0).toLocaleString();

    // First Pass Yield
    const fpyEl = kpiCards[1].querySelector('.font-label-mono-lg');
    if (fpyEl) fpyEl.textContent = `${summary.fpy}%`;

    // Overall Defect Rate
    const rateEl = kpiCards[2].querySelector('.font-label-mono-lg');
    if (rateEl) rateEl.textContent = `${summary.defectRate}%`;
  }

  // 2. Update Pareto Defect Distribution Chart (6 PCB Classes)
  renderParetoBars(summary.classCounts);
}

function renderParetoBars(counts) {
  const container = document.querySelector('.lg\\:col-span-7 .space-y-space-md');
  if (!container || !counts) return;

  const totalDefects = Object.values(counts).reduce((a, b) => a + b, 0) || 1;
  const totalDefectsSpan = document.querySelector('.lg\\:col-span-7 span.text-red-600.font-bold');
  if (totalDefectsSpan) totalDefectsSpan.textContent = totalDefects.toLocaleString();

  const defectList = [
    { key: 'short', name: 'Short Circuit', color: '#DC2626' },
    { key: 'missing_hole', name: 'Missing Hole', color: '#DC2626' },
    { key: 'mouse_bite', name: 'Mouse Bite', color: '#D97706' },
    { key: 'spur', name: 'Spur', color: '#D97706' },
    { key: 'open_circuit', name: 'Open Circuit', color: '#006194' },
    { key: 'spurious_copper', name: 'Spurious Copper', color: '#565e74' }
  ];

  // Sort descending by count
  defectList.sort((a, b) => (counts[b.key] || 0) - (counts[a.key] || 0));

  container.innerHTML = '';
  let cumulative = 0;

  defectList.forEach((item, idx) => {
    const count = counts[item.key] || 0;
    const pct = Number(((count / totalDefects) * 100).toFixed(1));
    cumulative += pct;
    const cumulPct = Math.min(cumulative, 100).toFixed(1);

    const barEl = document.createElement('div');
    barEl.innerHTML = `
      <div class="flex justify-between items-baseline font-label-ui text-label-ui mb-1">
        <span class="font-semibold text-on-surface flex items-center gap-1.5">
          <span class="w-2 h-2 rounded-sm" style="background-color: ${item.color}"></span>
          ${idx + 1}. ${item.name}
        </span>
        <span class="font-label-mono-sm text-label-mono-sm text-secondary">
          <strong class="text-on-surface">${count}</strong> (${pct}%) • Cumul: ${cumulPct}%
        </span>
      </div>
      <div class="w-full bg-surface-container rounded-sm h-3 overflow-hidden flex">
        <div class="h-full rounded-sm transition-all duration-300" 
             style="width: ${Math.max(pct, count > 0 ? 3 : 0)}%; background-color: ${item.color}"></div>
      </div>
    `;
    container.appendChild(barEl);
  });
}

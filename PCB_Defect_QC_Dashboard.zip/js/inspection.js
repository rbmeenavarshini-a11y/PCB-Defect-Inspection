/**
 * AOI VisionQC - New Inspection Page Controller
 * Handles Image Upload (Drag-Drop, Browse, Camera), YOLO Detection Rendering,
 * Defect Coordinate Ledger, PASS/FAIL Decision, and LLaMA Recommendations.
 */

const api = window.api;
const PCB_DEFECT_CLASSES = window.PCB_DEFECT_CLASSES;

let currentFile = null;
let currentInspection = null;

document.addEventListener('DOMContentLoaded', () => {
  setupNavigation();
  setupFileUpload();
  setupCameraCapture();
  setupInspectionTrigger();
  loadLastInspection();
});

// --- NAVIGATION HOOKS ---
function setupNavigation() {
  const navLinks = {
    'Overview': '../home.html',
    'New Inspection': '../new_inspection_defect_analysis/code.html',
    'Inspection History': '../inspection_history_records_reports/code.html',
    'Analytics': '../quality_analytics_trends/code.html',
    'System Status': '../system_status_diagnostics/code.html'
  };

  document.querySelectorAll('aside nav a').forEach(link => {
    const text = link.querySelector('span:last-child')?.textContent?.trim();
    if (navLinks[text]) {
      link.href = navLinks[text];
    }
  });

  // Quick Scan button in sidebar
  const quickScanBtn = document.querySelector('aside button:has(span[data-icon="qr_code_scanner"]), aside button:has(span[data-icon="center_focus_strong"])');
  if (quickScanBtn) {
    quickScanBtn.addEventListener('click', () => {
      document.getElementById('pcb-file-input')?.click();
    });
  }
}

// --- FILE UPLOAD (DRAG & DROP + BROWSE) ---
function setupFileUpload() {
  // Find or create hidden file input
  let fileInput = document.getElementById('pcb-file-input');
  if (!fileInput) {
    fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.id = 'pcb-file-input';
    fileInput.accept = 'image/jpeg,image/png,image/jpg';
    fileInput.className = 'hidden';
    document.body.appendChild(fileInput);
  }

  // Find the drag & drop area
  const dropArea = document.querySelector('section:has(span[data-icon="cloud_upload"]) .border-dashed') || 
                   document.querySelector('.border-dashed');

  // Find the browse button
  const browseBtn = Array.from(document.querySelectorAll('button')).find(b => b.textContent.includes('Browse Image'));

  if (browseBtn) {
    browseBtn.addEventListener('click', () => fileInput.click());
  }

  if (dropArea) {
    ['dragenter', 'dragover'].forEach(eventName => {
      dropArea.addEventListener(eventName, (e) => {
        e.preventDefault();
        e.stopPropagation();
        dropArea.classList.add('border-primary', 'bg-surface-container');
      });
    });

    ['dragleave', 'drop'].forEach(eventName => {
      dropArea.addEventListener(eventName, (e) => {
        e.preventDefault();
        e.stopPropagation();
        dropArea.classList.remove('border-primary', 'bg-surface-container');
      });
    });

    dropArea.addEventListener('drop', (e) => {
      const dt = e.dataTransfer;
      const files = dt.files;
      if (files.length > 0) {
        handleSelectedFile(files[0]);
      }
    });

    dropArea.style.cursor = 'pointer';
    dropArea.addEventListener('click', (e) => {
      if (!e.target.closest('button')) {
        fileInput.click();
      }
    });
  }

  fileInput.addEventListener('change', (e) => {
    if (e.target.files.length > 0) {
      handleSelectedFile(e.target.files[0]);
    }
  });
}

// --- FILE VALIDATION & PREVIEW ---
function handleSelectedFile(file) {
  const validTypes = ['image/jpeg', 'image/png', 'image/jpg'];
  const maxSize = 25 * 1024 * 1024; // 25MB

  if (!validTypes.includes(file.type)) {
    showNotification('Invalid File Type: Please upload a JPG, JPEG, or PNG image.', 'error');
    return;
  }

  if (file.size > maxSize) {
    showNotification('File Exceeds 25MB Limit: Please upload a smaller PCB image.', 'error');
    return;
  }

  currentFile = file;
  const objectUrl = URL.createObjectURL(file);

  // Update Original Image Viewport
  const originalImg = document.querySelector('section .grid > div:first-child img');
  if (originalImg) {
    originalImg.src = objectUrl;
  }

  // Update drop zone text
  const uploadTitle = document.querySelector('.border-dashed span.font-headline-sm');
  if (uploadTitle) {
    uploadTitle.innerHTML = `<span class="text-primary font-bold">Selected: ${file.name}</span> (${(file.size / (1024 * 1024)).toFixed(2)} MB)`;
  }

  showNotification(`Ready for inspection: ${file.name}`, 'info');
}

// --- CAMERA CAPTURE (Webcam Support) ---
function setupCameraCapture() {
  const cameraBtn = Array.from(document.querySelectorAll('button')).find(b => b.textContent.includes('Capture from Camera'));
  if (!cameraBtn) return;

  cameraBtn.addEventListener('click', async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      openCameraModal(stream);
    } catch (err) {
      showNotification('Camera access unavailable or permission denied. Please use file upload.', 'warning');
    }
  });
}

function openCameraModal(stream) {
  const modal = document.createElement('div');
  modal.className = 'fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4';
  modal.innerHTML = `
    <div class="bg-surface-container-lowest border border-outline-variant rounded-lg max-w-lg w-full p-4 flex flex-col gap-4">
      <div class="flex items-center justify-between pb-2 border-b border-outline-variant">
        <h3 class="font-headline-sm text-on-surface font-semibold flex items-center gap-2">
          <span class="material-symbols-outlined text-primary">photo_camera</span>
          Live Optical Capture
        </h3>
        <button id="close-camera" class="p-1 hover:bg-surface-container rounded text-outline">
          <span class="material-symbols-outlined">close</span>
        </button>
      </div>
      <video id="camera-stream" autoplay playsinline class="w-full aspect-[4/3] bg-black rounded"></video>
      <div class="flex justify-end gap-2">
        <button id="cancel-camera" class="px-3 py-1.5 border border-outline-variant rounded text-on-surface text-label-ui">Cancel</button>
        <button id="snap-photo" class="px-4 py-1.5 bg-primary text-on-primary font-bold rounded text-label-ui flex items-center gap-1">
          <span class="material-symbols-outlined text-[16px]">camera</span> Capture Frame
        </button>
      </div>
    </div>
  `;
  document.body.appendChild(modal);

  const video = modal.querySelector('#camera-stream');
  video.srcObject = stream;

  const closeStream = () => {
    stream.getTracks().forEach(t => t.stop());
    modal.remove();
  };

  modal.querySelector('#close-camera').onclick = closeStream;
  modal.querySelector('#cancel-camera').onclick = closeStream;

  modal.querySelector('#snap-photo').onclick = () => {
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 1280;
    canvas.height = video.videoHeight || 720;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    canvas.toBlob((blob) => {
      const file = new File([blob], `camera_capture_${Date.now()}.png`, { type: 'image/png' });
      handleSelectedFile(file);
      closeStream();
    }, 'image/png');
  };
}

// --- INSPECTION TRIGGER ---
function setupInspectionTrigger() {
  const startBtn = Array.from(document.querySelectorAll('button')).find(b => b.textContent.includes('Start Inspection'));
  if (!startBtn) return;

  startBtn.addEventListener('click', async () => {
    if (!currentFile) {
      showNotification('Please upload or capture a PCB image first.', 'warning');
      return;
    }

    // Set Loading State
    const originalText = startBtn.innerHTML;
    startBtn.disabled = true;
    startBtn.innerHTML = `
      <span class="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
      <span>Running YOLO & LLaMA Inference...</span>
    `;

    try {
      const response = await api.inspectPCB(currentFile);
      if (response && response.success) {
        currentInspection = response.data;
        renderInspectionResult(response.data);
        showNotification(
          response.is_demo 
            ? 'Inspection Complete (Demo Engine Active)' 
            : 'Inspection Complete (Live YOLO + LLaMA Inference)', 
          'success'
        );
      }
    } catch (err) {
      showNotification(`Inspection Failed: ${err.message}`, 'error');
    } finally {
      startBtn.disabled = false;
      startBtn.innerHTML = originalText;
    }
  });
}

// --- RENDER COMPLETE INSPECTION RESULTS ---
function renderInspectionResult(data) {
  // 1. Update Batch & Inspection Header Badges
  const batchBadge = document.querySelector('section span.font-label-mono-sm.text-primary');
  if (batchBadge) batchBadge.textContent = `Batch #${data.batch_number || 'SMT-2026-089A'}`;

  const demoBadge = document.querySelector('section span.font-label-mono-sm.text-on-surface-variant');
  if (demoBadge) {
    if (data.is_demo) {
      demoBadge.textContent = 'Demonstration Data - Simulated Rig';
      demoBadge.className = 'px-2 py-0.5 rounded font-label-mono-sm text-label-mono-sm bg-amber-100 text-amber-800 border border-amber-300 font-semibold';
    } else {
      demoBadge.textContent = 'Live Backend Feed - FastAPI + YOLO + LLaMA';
      demoBadge.className = 'px-2 py-0.5 rounded font-label-mono-sm text-label-mono-sm bg-emerald-100 text-emerald-800 border border-emerald-300 font-semibold';
    }
  }

  // 2. Update Detected PCB Image Viewport with Bounding Boxes
  renderAnnotatedImage(data);

  // 3. Update Prominent Official Decision Banner
  renderDecisionBanner(data);

  // 4. Update Defect Coordinate Ledger Table
  renderDefectTable(data);

  // 5. Update LLaMA AI Recommendations Card
  renderRecommendationCard(data);
}

// --- RENDER ANNOTATED IMAGE WITH DYNAMIC BOUNDING BOXES ---
function renderAnnotatedImage(data) {
  const detectedFrame = document.querySelector('section .grid > div:last-child');
  if (!detectedFrame) return;

  const detectedImg = detectedFrame.querySelector('img');
  if (detectedImg) {
    detectedImg.src = data.annotated_image || data.original_image;
  }

  // Header defect tag
  const statusTag = detectedFrame.querySelector('.font-label-mono-sm span.rounded');
  if (statusTag) {
    const defectCount = data.defects ? data.defects.length : 0;
    if (defectCount === 0) {
      statusTag.textContent = 'ZERO DEFECTS • NOMINAL';
      statusTag.className = 'px-1.5 py-0.5 rounded bg-emerald-100 border border-emerald-300 text-emerald-700 font-bold uppercase';
    } else {
      statusTag.textContent = `${defectCount} DEFECTS FLAGGED`;
      statusTag.className = 'px-1.5 py-0.5 rounded bg-red-100 border border-red-300 text-red-700 font-bold uppercase';
    }
  }

  // Clear existing bounding box overlays (keep img, grid, reticles, telemetry tag)
  const viewport = detectedFrame.querySelector('.relative.w-full.aspect-\\[16\\/10\\]');
  if (viewport) {
    viewport.querySelectorAll('.defect-bbox-overlay').forEach(el => el.remove());

    // Render new bounding boxes
    if (data.defects && data.defects.length > 0) {
      data.defects.forEach(defect => {
        const bbox = defect.bbox;
        const color = defect.severity === 'CRITICAL' ? '#DC2626' : '#D97706';
        const bgColor = defect.severity === 'CRITICAL' ? 'rgba(220, 38, 38, 0.12)' : 'rgba(217, 119, 6, 0.12)';

        const boxEl = document.createElement('div');
        boxEl.className = 'defect-bbox-overlay absolute pointer-events-none transition-all duration-200';
        boxEl.style.top = `${bbox.y1}%`;
        boxEl.style.left = `${bbox.x1}%`;
        boxEl.style.width = `${Math.max(bbox.x2 - bbox.x1, 12)}%`;
        boxEl.style.height = `${Math.max(bbox.y2 - bbox.y1, 12)}%`;
        boxEl.style.border = `2px solid ${color}`;
        boxEl.style.backgroundColor = bgColor;

        boxEl.innerHTML = `
          <div class="absolute -top-6 left-0 font-label-mono-sm text-label-mono-sm font-bold px-1.5 py-0.5 rounded-sm whitespace-nowrap shadow-none flex items-center gap-1"
               style="background-color: ${color}; color: #ffffff;">
            <span class="material-symbols-outlined text-[12px]">${defect.severity === 'CRITICAL' ? 'close' : 'warning'}</span>
            <span>${defect.display_name} ${(defect.confidence * 100).toFixed(1)}%</span>
          </div>
          <span class="absolute -top-1 -left-1 w-2 h-2" style="background-color: ${color};"></span>
          <span class="absolute -bottom-1 -right-1 w-2 h-2" style="background-color: ${color};"></span>
        `;
        viewport.appendChild(boxEl);
      });
    }
  }
}

// --- RENDER DECISION BANNER (PASS / FAIL / REVIEW) ---
function renderDecisionBanner(data) {
  const banner = document.querySelector('section:has(.font-headline-lg):has(button)');
  if (!banner) return;

  const status = data.status || 'PASS';
  const iconSpan = banner.querySelector('.material-symbols-outlined');
  const titleSpan = banner.querySelector('.font-headline-lg');
  const subBadge = banner.querySelector('.font-label-mono-sm.uppercase');
  const descP = banner.querySelector('p.font-body-md');
  const iconBox = banner.querySelector('div.w-12.h-12');

  if (status === 'PASS') {
    banner.className = 'bg-[#DCFCE7] border-2 border-emerald-500 rounded-lg p-space-md flex flex-col md:flex-row items-start md:items-center justify-between gap-space-md';
    if (iconBox) iconBox.className = 'w-12 h-12 rounded bg-emerald-600 text-white flex items-center justify-center shrink-0';
    if (iconSpan) iconSpan.textContent = 'check_circle';
    if (titleSpan) {
      titleSpan.textContent = 'PASS (Meets IPC-A-610 Class 3 Inspection Criteria)';
      titleSpan.className = 'font-headline-lg text-headline-lg font-bold text-emerald-800 tracking-tight';
    }
    if (subBadge) {
      subBadge.textContent = 'LINE CLEAR • ADVANCE TO PACK';
      subBadge.className = 'px-2 py-0.5 bg-emerald-700 text-white rounded font-label-mono-sm text-label-mono-sm font-bold uppercase tracking-wide';
    }
    if (descP) {
      descP.textContent = data.status_reason || 'Zero defects detected. PCB panel passed automated optical tolerance standards.';
      descP.className = 'font-body-md text-body-md text-emerald-900 mt-1 font-medium';
    }
  } else if (status === 'REVIEW') {
    banner.className = 'bg-[#FEF3C7] border-2 border-amber-500 rounded-lg p-space-md flex flex-col md:flex-row items-start md:items-center justify-between gap-space-md';
    if (iconBox) iconBox.className = 'w-12 h-12 rounded bg-amber-600 text-white flex items-center justify-center shrink-0';
    if (iconSpan) iconSpan.textContent = 'help';
    if (titleSpan) {
      titleSpan.textContent = 'REVIEW (Ambiguous Inspection Condition - Human QC Required)';
      titleSpan.className = 'font-headline-lg text-headline-lg font-bold text-amber-900 tracking-tight';
    }
    if (subBadge) {
      subBadge.textContent = 'MANUAL VERIFICATION HOLD';
      subBadge.className = 'px-2 py-0.5 bg-amber-700 text-white rounded font-label-mono-sm text-label-mono-sm font-bold uppercase tracking-wide';
    }
    if (descP) {
      descP.textContent = data.status_reason || 'Low-confidence anomaly requires engineer microscope inspection.';
      descP.className = 'font-body-md text-body-md text-amber-950 mt-1 font-medium';
    }
  } else {
    // FAIL
    banner.className = 'bg-[#FEE2E2] border-2 border-red-500 rounded-lg p-space-md flex flex-col md:flex-row items-start md:items-center justify-between gap-space-md';
    if (iconBox) iconBox.className = 'w-12 h-12 rounded bg-red-600 text-white flex items-center justify-center shrink-0';
    if (iconSpan) iconSpan.textContent = 'cancel';
    if (titleSpan) {
      titleSpan.textContent = 'FAIL (Defects Exceed IPC-A-610 Class 3 Tolerance)';
      titleSpan.className = 'font-headline-lg text-headline-lg font-bold text-red-700 tracking-tight';
    }
    if (subBadge) {
      subBadge.textContent = 'AUTOMATED LOCK TRIGGERED';
      subBadge.className = 'px-2 py-0.5 bg-red-700 text-white rounded font-label-mono-sm text-label-mono-sm font-bold uppercase tracking-wide';
    }
    if (descP) {
      descP.textContent = data.status_reason || 'Critical anomalies identified. Board routed to Manual Rework Station #02.';
      descP.className = 'font-body-md text-body-md text-red-900 mt-1 font-medium';
    }
  }
}

// --- RENDER DEFECT TABLE ---
function renderDefectTable(data) {
  const tbody = document.querySelector('section table tbody');
  const totalCountSpan = document.querySelector('section:has(table) .font-label-mono-sm.text-outline span:first-child');
  
  if (totalCountSpan) {
    totalCountSpan.textContent = `TOTAL DEFECTS DETECTED: ${data.defects ? data.defects.length : 0}`;
  }

  if (!tbody) return;
  tbody.innerHTML = '';

  if (!data.defects || data.defects.length === 0) {
    const emptyRow = document.createElement('tr');
    emptyRow.innerHTML = `
      <td colspan="8" class="py-6 text-center text-on-surface-variant font-body-md">
        <div class="flex flex-col items-center justify-center gap-1 text-emerald-700">
          <span class="material-symbols-outlined text-[28px]">check_circle</span>
          <span class="font-bold">No surface defects detected on this PCB.</span>
          <span class="font-label-mono-sm text-outline">IPC-A-610 Class 3 Criteria: PASSED</span>
        </div>
      </td>
    `;
    tbody.appendChild(emptyRow);
    return;
  }

  data.defects.forEach(defect => {
    const row = document.createElement('tr');
    row.className = 'hover:bg-surface-container-low/50 transition-colors';
    const isCrit = defect.severity === 'CRITICAL';
    const colorClass = isCrit ? 'text-red-600' : 'text-amber-600';
    const badgeClass = isCrit ? 'bg-[#FEE2E2] text-red-700 border-red-300' : 'bg-[#FEF3C7] text-amber-800 border-amber-300';
    const dotColor = isCrit ? 'bg-red-600' : 'bg-amber-500';

    row.innerHTML = `
      <td class="py-2.5 px-space-md font-label-mono-sm text-label-mono-sm font-bold text-primary">${defect.defect_id}</td>
      <td class="py-2.5 px-space-md flex items-center gap-2">
        <span class="w-2 h-2 rounded-full ${dotColor}"></span>
        <span class="font-semibold text-on-surface">${defect.display_name}</span>
      </td>
      <td class="py-2.5 px-space-md text-right font-label-mono-md text-label-mono-md font-semibold ${colorClass}">
        ${(defect.confidence * 100).toFixed(1)}%
      </td>
      <td class="py-2.5 px-space-md text-right font-label-mono-md text-label-mono-md text-on-surface-variant">
        X1: ${defect.bbox.x1}, Y1: ${defect.bbox.y1}
      </td>
      <td class="py-2.5 px-space-md text-right font-label-mono-md text-label-mono-md text-on-surface-variant">
        X2: ${defect.bbox.x2}, Y2: ${defect.bbox.y2}
      </td>
      <td class="py-2.5 px-space-md text-center">
        <span class="inline-block px-2 py-0.5 rounded font-label-mono-sm text-label-mono-sm font-bold border ${badgeClass}">
          ${defect.severity}
        </span>
      </td>
      <td class="py-2.5 px-space-md text-right font-label-mono-sm text-label-mono-sm font-semibold">
        ${defect.ref_des || 'Panel Area'}
      </td>
      <td class="py-2.5 px-space-md text-center">
        <button class="p-1 text-primary hover:bg-surface-container rounded" title="Pinpoint in Viewport">
          <span class="material-symbols-outlined text-[16px]">filter_center_focus</span>
        </button>
      </td>
    `;
    tbody.appendChild(row);
  });
}

// --- RENDER LLAMA RECOMMENDATION CARD ---
function renderRecommendationCard(data) {
  const recSection = document.querySelector('section:has(h3:has-text("AI Quality Recommendations")), section:has(span[data-icon="psychology"])');
  if (!recSection) return;

  const rec = data.recommendation;
  if (!rec) return;

  // Panel 1: Detected Defect Summary
  const summaryP = recSection.querySelectorAll('.grid > div')[0]?.querySelector('p.font-body-md');
  const rootCauseDiv = recSection.querySelectorAll('.grid > div')[0]?.querySelector('div.font-label-mono-sm');
  if (summaryP) summaryP.textContent = rec.summary || 'Summary unavailable.';
  if (rootCauseDiv) rootCauseDiv.textContent = `ROOT CAUSE: ${rec.root_cause || 'Nominal'}`;

  // Panel 2: Corrective Actions
  const actionsList = recSection.querySelectorAll('.grid > div')[1]?.querySelector('ol');
  const downtimeDiv = recSection.querySelectorAll('.grid > div')[1]?.querySelector('div.font-label-mono-sm');
  if (actionsList) {
    actionsList.innerHTML = '';
    (rec.corrective_actions || []).forEach(action => {
      const li = document.createElement('li');
      li.textContent = action;
      actionsList.appendChild(li);
    });
  }
  if (downtimeDiv) downtimeDiv.textContent = `ESTIMATED DOWNTIME: ${rec.estimated_downtime || '0 mins'}`;

  // Panel 3: Manual Verification
  const verificationP = recSection.querySelectorAll('.grid > div')[2]?.querySelector('p.font-body-md');
  if (verificationP) verificationP.textContent = rec.manual_verification || 'Standard lot sampling.';
}

// --- INITIAL LOAD FROM STORAGE ---
function loadLastInspection() {
  const inspections = api.getSavedInspections();
  if (inspections && inspections.length > 0) {
    currentInspection = inspections[0];
    renderInspectionResult(currentInspection);
  }
}

// --- NOTIFICATION TOAST ---
function showNotification(message, type = 'info') {
  const existing = document.getElementById('aoi-notification');
  if (existing) existing.remove();

  const toast = document.createElement('div');
  toast.id = 'aoi-notification';
  toast.className = `fixed bottom-6 right-6 z-50 px-4 py-2.5 rounded shadow-lg flex items-center gap-2 font-label-ui text-label-ui border text-white transition-all duration-300 ${
    type === 'error' ? 'bg-red-700 border-red-800' :
    type === 'warning' ? 'bg-amber-600 border-amber-700' :
    type === 'success' ? 'bg-emerald-700 border-emerald-800' :
    'bg-primary border-primary-container'
  }`;
  toast.innerHTML = `
    <span class="material-symbols-outlined text-[18px]">
      ${type === 'error' ? 'error' : type === 'warning' ? 'warning' : type === 'success' ? 'check_circle' : 'info'}
    </span>
    <span>${message}</span>
  `;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 4000);
}

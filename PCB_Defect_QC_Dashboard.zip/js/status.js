/**
 * AOI VisionQC - System Status & Edge Diagnostics Controller
 * Queries FastAPI /health endpoint and monitors runtime health
 * for YOLO, PyTorch, OpenCV, LLaMA, FastAPI, SQLite, ExecuTorch, and Raspberry Pi 5.
 */

const api = window.api;

document.addEventListener('DOMContentLoaded', () => {
  setupNavigation();
  checkSystemHealth();
  setupActionButtons();
});

function setupNavigation() {
  const navLinks = {
    'Overview': '../home.html',
    'New Inspection': '../new_inspection_defect_analysis/code.html',
    'Inspection History': '../inspection_history_records_reports/code.html',
    'Analytics': '../quality_analytics_trends/code.html',
    'System Status': '../system_status_diagnostics/code.html'
  };

  document.querySelectorAll('aside nav a').forEach(link => {
    const text = link.querySelector('span:last-child')?.textContent?.trim();
    if (navLinks[text]) {
      link.href = navLinks[text];
    }
  });

  document.querySelectorAll('button').forEach(btn => {
    if (btn.textContent.includes('Quick Scan')) {
      btn.addEventListener('click', () => {
        window.location.href = '../new_inspection_defect_analysis/code.html';
      });
    }
  });
}

function setupActionButtons() {
  const diagBtn = Array.from(document.querySelectorAll('button')).find(b => b.textContent.includes('Run Diagnostics'));
  if (diagBtn) {
    diagBtn.addEventListener('click', async () => {
      diagBtn.disabled = true;
      diagBtn.innerHTML = `
        <span class="inline-block w-3.5 h-3.5 border-2 border-primary border-t-transparent rounded-full animate-spin"></span>
        <span>Probing Nodes...</span>
      `;
      await checkSystemHealth();
      diagBtn.disabled = false;
      diagBtn.innerHTML = `
        <span class="material-symbols-outlined text-[16px] text-primary">play_circle</span>
        <span>Run Diagnostics</span>
      `;
    });
  }
}

async function checkSystemHealth() {
  const health = await api.checkHealth();
  const banner = document.querySelector('section.bg-emerald-50, section.bg-amber-50');
  
  if (banner) {
    const title = banner.querySelector('.font-headline-sm');
    const badge = banner.querySelector('.font-label-mono-sm.uppercase');
    const desc = banner.querySelector('p.font-body-sm');
    const icon = banner.querySelector('.material-symbols-outlined');

    if (health.online) {
      banner.className = 'bg-emerald-50 border border-emerald-200 rounded p-space-md flex items-center justify-between';
      if (icon) {
        icon.textContent = 'check_circle';
        icon.parentElement.className = 'w-8 h-8 rounded bg-emerald-600 text-white flex items-center justify-center';
      }
      if (title) title.textContent = 'FastAPI Backend & AI Pipeline CONNECTED — All Core Services Online';
      if (badge) {
        badge.textContent = 'ONLINE';
        badge.className = 'px-2 py-0.5 rounded text-[10px] font-label-mono-sm bg-emerald-100 text-emerald-800 border border-emerald-300 font-semibold uppercase';
      }
      if (desc) desc.textContent = `Connected to http://localhost:8000. YOLOv8 and LLaMA 3.2 are loaded and responsive.`;
    } else {
      banner.className = 'bg-amber-50 border border-amber-300 rounded p-space-md flex items-center justify-between';
      if (icon) {
        icon.textContent = 'info';
        icon.parentElement.className = 'w-8 h-8 rounded bg-amber-600 text-white flex items-center justify-center';
      }
      if (title) title.textContent = 'Demonstration Diagnostic Mode Active — Simulated Edge Telemetry';
      if (badge) {
        badge.textContent = 'SIMULATED';
        badge.className = 'px-2 py-0.5 rounded text-[10px] font-label-mono-sm bg-amber-100 text-amber-800 border border-amber-300 font-semibold uppercase';
      }
      if (desc) desc.textContent = 'FastAPI server (http://localhost:8000) not detected. All UI controls and inspection workflows are operating in Demo Mode.';
    }
  }

  // Update component cards
  updateComponentCard('YOLO Detection Model', health.online ? 'CONNECTED' : 'SIMULATED (DEMO)');
  updateComponentCard('LLaMA Recommendation Model', health.online ? 'CONNECTED' : 'SIMULATED (DEMO)');
}

function updateComponentCard(name, statusText) {
  const headings = Array.from(document.querySelectorAll('h4'));
  const h = headings.find(el => el.textContent.includes(name));
  if (!h) return;

  const card = h.closest('.bg-surface-container-lowest');
  const badge = card?.querySelector('.font-label-mono-sm.uppercase');
  if (badge) {
    badge.textContent = statusText;
    if (statusText.includes('CONNECTED')) {
      badge.className = 'inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] font-label-mono-sm font-semibold uppercase bg-emerald-50 text-emerald-700 border border-emerald-300';
    } else {
      badge.className = 'inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] font-label-mono-sm font-semibold uppercase bg-amber-50 text-amber-700 border border-amber-300';
    }
  }
}

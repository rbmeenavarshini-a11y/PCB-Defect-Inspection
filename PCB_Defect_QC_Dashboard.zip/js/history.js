/**
 * AOI VisionQC - Inspection History & Audit Logs Controller
 * Handles Search, Filter chips (All/PASS/FAIL/REVIEW),
 * and the Interactive Inspection Detail Drawer.
 */

const api = window.api;

let allRecords = [];
let filteredRecords = [];
let currentFilter = 'All';
let currentSearch = '';
let currentDefectClass = 'All';

document.addEventListener('DOMContentLoaded', () => {
  setupNavigation();
  loadHistory();
  setupFiltersAndSearch();
});

function setupNavigation() {
  const navLinks = {
    'Overview': '../home.html',
    'New Inspection': '../new_inspection_defect_analysis/code.html',
    'Inspection History': '../inspection_history_records_reports/code.html',
    'Analytics': '../quality_analytics_trends/code.html',
    'System Status': '../system_status_diagnostics/code.html'
  };

  document.querySelectorAll('aside nav a').forEach(link => {
    const text = link.querySelector('span:last-child')?.textContent?.trim();
    if (navLinks[text]) {
      link.href = navLinks[text];
    }
  });

  document.querySelectorAll('button').forEach(btn => {
    if (btn.textContent.includes('Quick Scan')) {
      btn.addEventListener('click', () => {
        window.location.href = '../new_inspection_defect_analysis/code.html';
      });
    }
  });
}

function loadHistory() {
  allRecords = api.getSavedInspections() || [];
  filteredRecords = [...allRecords];
  updateFilterCounts();
  renderTable();
  if (filteredRecords.length > 0) {
    selectRecord(filteredRecords[0]);
  }
}

function setupFiltersAndSearch() {
  // Search input
  const searchInput = document.querySelector('input[placeholder*="Search by Inspection ID"]');
  if (searchInput) {
    searchInput.value = '';
    searchInput.addEventListener('input', (e) => {
      currentSearch = e.target.value.toLowerCase().trim();
      applyFilters();
    });
  }

  // Filter Chips (All, PASS, FAIL, REVIEW)
  const filterBtns = document.querySelectorAll('.flex.flex-wrap.items-center.gap-space-sm button');
  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const label = btn.querySelector('span:first-child')?.textContent?.trim();
      if (['All', 'PASS', 'FAIL', 'REVIEW'].includes(label)) {
        currentFilter = label;

        // Update active styling
        filterBtns.forEach(b => {
          b.classList.remove('border-2', 'shadow-sm');
          b.querySelector('span[data-icon="check"]')?.remove();
        });
        btn.classList.add('border-2', 'shadow-sm');
        const checkIcon = document.createElement('span');
        checkIcon.className = 'material-symbols-outlined text-[14px]';
        checkIcon.setAttribute('data-icon', 'check');
        checkIcon.textContent = 'check';
        btn.appendChild(checkIcon);

        applyFilters();
      }
    });
  });

  // Defect Class Dropdown
  const defectSelect = document.querySelector('select:has(option:contains("All"))') || document.querySelectorAll('select')[0];
  if (defectSelect) {
    defectSelect.addEventListener('change', (e) => {
      currentDefectClass = e.target.value;
      applyFilters();
    });
  }
}

function updateFilterCounts() {
  const counts = {
    All: allRecords.length,
    PASS: allRecords.filter(r => r.status === 'PASS').length,
    FAIL: allRecords.filter(r => r.status === 'FAIL').length,
    REVIEW: allRecords.filter(r => r.status === 'REVIEW').length
  };

  document.querySelectorAll('.flex.flex-wrap.items-center.gap-space-sm button').forEach(btn => {
    const label = btn.querySelector('span:first-child')?.textContent?.trim();
    const countSpan = btn.querySelector('span.font-label-mono-sm');
    if (label && counts[label] !== undefined && countSpan) {
      countSpan.textContent = counts[label].toLocaleString();
    }
  });
}

function applyFilters() {
  filteredRecords = allRecords.filter(r => {
    // 1. Status Filter
    if (currentFilter !== 'All' && r.status !== currentFilter) {
      return false;
    }
    // 2. Search Filter
    if (currentSearch) {
      const matchId = (r.inspection_id || '').toLowerCase().includes(currentSearch);
      const matchBatch = (r.batch_number || '').toLowerCase().includes(currentSearch);
      const matchDefects = (r.defects || []).some(d => 
        (d.display_name || '').toLowerCase().includes(currentSearch) ||
        (d.class_name || '').toLowerCase().includes(currentSearch)
      );
      if (!matchId && !matchBatch && !matchDefects) return false;
    }
    // 3. Defect Class Dropdown Filter
    if (currentDefectClass !== 'All' && currentDefectClass !== 'All 6') {
      const hasClass = (r.defects || []).some(d => 
        d.display_name.toLowerCase().includes(currentDefectClass.toLowerCase())
      );
      if (!hasClass) return false;
    }
    return true;
  });

  // Update total filtered count text
  const resultSummary = document.querySelector('.ml-auto.text-on-surface-variant.font-label-mono-sm');
  if (resultSummary) {
    resultSummary.textContent = `Showing 1 - ${filteredRecords.length} of ${filteredRecords.length} filtered results`;
  }

  const tableSummary = document.querySelector('.px-space-md.py-space-sm.border-t span:first-child');
  if (tableSummary) {
    tableSummary.textContent = `Total Records: ${filteredRecords.length} matching`;
  }

  renderTable();
}

function renderTable() {
  const tbody = document.querySelector('table tbody');
  if (!tbody) return;
  tbody.innerHTML = '';

  if (filteredRecords.length === 0) {
    const empty = document.createElement('tr');
    empty.innerHTML = `
      <td colspan="6" class="py-8 text-center text-secondary font-body-md">
        No inspection records match the current filter or search criteria.
      </td>
    `;
    tbody.appendChild(empty);
    return;
  }

  filteredRecords.forEach((rec, index) => {
    const row = document.createElement('tr');
    row.className = 'hover:bg-surface-container-low transition-colors duration-100 cursor-pointer';
    
    const isPass = rec.status === 'PASS';
    const isFail = rec.status === 'FAIL';
    const badgeBg = isPass ? 'bg-[#DCFCE7] text-[#16A34A] border-[#86EFAC]' :
                    isFail ? 'bg-[#FEE2E2] text-[#DC2626] border-[#FCA5A5]' :
                    'bg-[#FEF3C7] text-[#D97706] border-[#FCD34D]';

    const defectsSummary = !rec.defects || rec.defects.length === 0 
      ? 'None - Pass' 
      : `${rec.defects.length} (${rec.defects.map(d => d.display_name).join(', ')})`;

    const dateStr = rec.timestamp ? new Date(rec.timestamp).toLocaleString() : 'Recent';

    row.innerHTML = `
      <td class="py-2.5 px-space-md font-label-mono-sm text-label-mono-sm font-semibold text-primary">#${rec.inspection_id}</td>
      <td class="py-2.5 px-space-md font-label-mono-sm text-label-mono-sm text-on-surface-variant">${dateStr}</td>
      <td class="py-2.5 px-space-md">
        <div class="font-label-mono-sm text-label-mono-sm font-medium">${rec.batch_number || 'SMT-2026-089A'}</div>
      </td>
      <td class="py-2.5 px-space-md">
        <span class="inline-flex items-center gap-1 font-label-ui text-label-ui ${isFail ? 'text-error font-medium' : isPass ? 'text-on-surface-variant' : 'text-amber-700'}">
          ${isFail ? '<span class="material-symbols-outlined text-[14px]">error</span>' : ''}
          ${defectsSummary}
        </span>
      </td>
      <td class="py-2.5 px-space-md">
        <span class="px-2 py-0.5 rounded text-[11px] font-label-mono-sm font-bold border ${badgeBg}">
          ${rec.status}
        </span>
      </td>
      <td class="py-2.5 px-space-md text-right">
        <button class="view-btn inline-flex items-center gap-1 px-space-sm py-1 bg-surface-container-lowest border border-outline-variant hover:bg-surface-container rounded font-label-ui text-label-ui text-on-surface font-medium transition-colors">
          <span class="material-symbols-outlined text-[14px] text-on-surface-variant">visibility</span>
          View Report
        </button>
      </td>
    `;

    row.addEventListener('click', () => {
      document.querySelectorAll('tbody tr').forEach(r => r.classList.remove('border-l-4', 'border-l-primary', 'bg-surface-container-high/40'));
      row.classList.add('border-l-4', 'border-l-primary', 'bg-surface-container-high/40');
      selectRecord(rec);
    });

    tbody.appendChild(row);
  });
}

function selectRecord(rec) {
  const drawer = document.querySelector('.col-span-12.xl\\:col-span-5');
  if (!drawer || !rec) return;

  // Title and Status Badge
  const titleSpan = drawer.querySelector('.font-headline-md');
  const badgeSpan = drawer.querySelector('.font-headline-md + span');
  const metaDiv = drawer.querySelector('.font-label-mono-sm.text-on-surface-variant');

  if (titleSpan) titleSpan.textContent = `Inspection Record: #${rec.inspection_id}`;
  if (badgeSpan) {
    badgeSpan.textContent = rec.status;
    badgeSpan.className = rec.status === 'PASS' 
      ? 'px-2 py-0.5 rounded text-[11px] font-label-mono-sm font-bold bg-[#DCFCE7] text-[#16A34A] border border-[#86EFAC]'
      : rec.status === 'FAIL'
      ? 'px-2 py-0.5 rounded text-[11px] font-label-mono-sm font-bold bg-[#FEE2E2] text-[#DC2626] border border-[#FCA5A5]'
      : 'px-2 py-0.5 rounded text-[11px] font-label-mono-sm font-bold bg-[#FEF3C7] text-[#D97706] border border-[#FCD34D]';
  }
  if (metaDiv) {
    metaDiv.innerHTML = `Batch: <span class="text-on-surface font-semibold">${rec.batch_number || 'SMT-2026-089A'}</span> | Timestamp: <span class="text-on-surface">${new Date(rec.timestamp).toLocaleString()}</span>`;
  }

  // Original & Annotated Images
  const imgContainers = drawer.querySelectorAll('.grid.grid-cols-2 > div img');
  if (imgContainers.length >= 2) {
    imgContainers[0].src = rec.original_image;
    imgContainers[1].src = rec.annotated_image || rec.original_image;
  }

  // Defect summary list in drawer
  const defectListContainer = drawer.querySelector('.space-y-1\\.5');
  if (defectListContainer) {
    defectListContainer.innerHTML = '';
    if (!rec.defects || rec.defects.length === 0) {
      defectListContainer.innerHTML = `
        <div class="p-space-xs rounded bg-surface-container-lowest border border-outline-variant font-label-mono-sm text-label-mono-sm text-emerald-700 flex items-center gap-1.5">
          <span class="material-symbols-outlined text-[16px]">verified</span>
          <span>Zero defects flagged. All parameters nominal.</span>
        </div>
      `;
    } else {
      rec.defects.forEach((d, i) => {
        const item = document.createElement('div');
        item.className = 'p-space-xs rounded bg-surface-container-lowest border border-outline-variant flex items-center justify-between font-label-mono-sm text-label-mono-sm';
        item.innerHTML = `
          <div class="flex items-center gap-2">
            <span class="w-2 h-2 rounded-full ${d.severity === 'CRITICAL' ? 'bg-error' : 'bg-amber-500'}"></span>
            <div>
              <span class="font-bold text-on-surface">Defect ${i+1}: ${d.display_name} ${d.ref_des ? `(${d.ref_des})` : ''}</span>
              <span class="${d.severity === 'CRITICAL' ? 'text-error' : 'text-amber-700'} font-semibold ml-1.5">(Conf: ${(d.confidence * 100).toFixed(1)}%)</span>
            </div>
          </div>
          <div class="text-on-surface-variant font-mono text-[11px] bg-surface-container px-1.5 py-0.5 rounded">
            [X1:${d.bbox.x1}, Y1:${d.bbox.y1}, X2:${d.bbox.x2}, Y2:${d.bbox.y2}]
          </div>
        `;
        defectListContainer.appendChild(item);
      });
    }
  }

  // AI Recommendation
  const recP = drawer.querySelector('.p-space-sm.rounded.bg-surface-container-low p.font-body-sm');
  if (recP && rec.recommendation) {
    recP.textContent = rec.recommendation.summary || 'Standard monitoring recommended.';
  }
}

/**
 * AOI VisionQC - Centralized Backend API Service & Demonstration Layer
 * Compatible with both local file:// execution and HTTP server execution.
 * Backend URL: http://localhost:8000
 */

(function(global) {
  const API_CONFIG = {
    BASE_URL: 'http://localhost:8000',
    TIMEOUT_MS: 15000,
    STORAGE_KEY_INSPECTIONS: 'aoi_pcb_inspections',
    STORAGE_KEY_DEMO_MODE: 'aoi_demo_mode_override',
  };

  // Standard PCB Defect Classes
  const PCB_DEFECT_CLASSES = [
    { id: 'mouse_bite', name: 'Mouse Bite', severity: 'MAJOR', standard: 'IPC-A-610 7.3.1', color: '#DC2626' },
    { id: 'spur', name: 'Spur', severity: 'MINOR', standard: 'IPC-A-610 7.3.2', color: '#D97706' },
    { id: 'missing_hole', name: 'Missing Hole', severity: 'CRITICAL', standard: 'IPC-A-610 7.2.1', color: '#DC2626' },
    { id: 'short', name: 'Short Circuit', severity: 'CRITICAL', standard: 'IPC-A-610 7.4.1', color: '#DC2626' },
    { id: 'open_circuit', name: 'Open Circuit', severity: 'CRITICAL', standard: 'IPC-A-610 7.4.2', color: '#DC2626' },
    { id: 'spurious_copper', name: 'Spurious Copper', severity: 'MAJOR', standard: 'IPC-A-610 7.3.3', color: '#D97706' }
  ];

  // Initial Seed Data for Demo Mode
  const INITIAL_DEMO_INSPECTIONS = [
    {
      inspection_id: "PCB-2026-089",
      timestamp: "2026-11-10T14:26:47Z",
      batch_number: "SMT-2026-089A",
      status: "FAIL",
      status_reason: "2 critical anomalies identified: Missing Hole in drill array 04 and Short Circuit at U3 Pin 4-5. IPC-A-610 Class 3 exceeded.",
      original_image: "https://lh3.googleusercontent.com/aida-public/AB6AXuCZs0MJzgzJ5Yzpfz5NHkS07lvPptu4x7IGy99wNIHdmhYwqLDt2kXrXxo_5bmLEbXuzmOWNoNdL-1KYblRU_lnxxnrnQvPEXA5XjhAO4ePCXe0GqNXdsDp87sdYAiSE5Vl4-pWC53vPNMpTPCCmaakVM6bfbpievGQvX3_v1M845fgoXYBB0hVXmarIEnozWD_QxUVPcsJyB0L9sOTYTnMp4ngiq5u2pQTTxL0VjH-",
      annotated_image: "https://lh3.googleusercontent.com/aida-public/AB6AXuDst7hvFVzju9eEZ1lju-YbozhpmuDAOeJWu5xZamacSoAD8lDU3hOHWe6S-cPwu_pSNBNG0AtQIoGtiScdudB8hQ4YdmCKqlKcLT87x3V8pyOL6JMKzliQrYwk78cFtHUwG986HnUaDbaBZJW8Uz6yNZhRjPrv--QuOxRnJami5mFd6052zq60qPSaObp_X6PyhPC_xzk2QO4Q7p7KXp3cgWmf8DmF7f3dBGiiqMnb",
      defects: [
        {
          defect_id: "DF-089-01",
          class_name: "missing_hole",
          display_name: "Missing Hole",
          confidence: 0.96,
          severity: "CRITICAL",
          ref_des: "H4 (Via Array 08)",
          bbox: { x1: 26, y1: 28, x2: 48, y2: 52 }
        },
        {
          defect_id: "DF-089-02",
          class_name: "short",
          display_name: "Short Circuit",
          confidence: 0.89,
          severity: "CRITICAL",
          ref_des: "U3 (SOIC-8 Pin 4-5)",
          bbox: { x1: 62, y1: 54, x2: 82, y2: 74 }
        }
      ],
      recommendation: {
        summary: "High-probability drill feed slip at spindle #4 and solder stencil paste overshoot.",
        root_cause: "Mechanical Drill Feed Jam / Stencil Aperture Smear",
        corrective_actions: [
          "Inspect vacuum pressure & bit condition on CNC Drill Spindle #4.",
          "Clean solder stencil aperture mask for IC footprint U3.",
          "Re-run calibration board before resuming high-speed run."
        ],
        manual_verification: "Requires operator physical check of via barrel conductivity before line restart.",
        estimated_downtime: "~4.5 mins"
      },
      is_demo: true
    },
    {
      inspection_id: "PCB-2026-088",
      timestamp: "2026-11-10T14:15:10Z",
      batch_number: "SMT-2026-089A",
      status: "PASS",
      status_reason: "Zero critical defects detected. All conductor clearances within IPC-A-610 Class 3 spec.",
      original_image: "https://lh3.googleusercontent.com/aida-public/AB6AXuCZs0MJzgzJ5Yzpfz5NHkS07lvPptu4x7IGy99wNIHdmhYwqLDt2kXrXxo_5bmLEbXuzmOWNoNdL-1KYblRU_lnxxnrnQvPEXA5XjhAO4ePCXe0GqNXdsDp87sdYAiSE5Vl4-pWC53vPNMpTPCCmaakVM6bfbpievGQvX3_v1M845fgoXYBB0hVXmarIEnozWD_QxUVPcsJyB0L9sOTYTnMp4ngiq5u2pQTTxL0VjH-",
      annotated_image: "https://lh3.googleusercontent.com/aida-public/AB6AXuCZs0MJzgzJ5Yzpfz5NHkS07lvPptu4x7IGy99wNIHdmhYwqLDt2kXrXxo_5bmLEbXuzmOWNoNdL-1KYblRU_lnxxnrnQvPEXA5XjhAO4ePCXe0GqNXdsDp87sdYAiSE5Vl4-pWC53vPNMpTPCCmaakVM6bfbpievGQvX3_v1M845fgoXYBB0hVXmarIEnozWD_QxUVPcsJyB0L9sOTYTnMp4ngiq5u2pQTTxL0VjH-",
      defects: [],
      recommendation: {
        summary: "Board meets all IPC-A-610 Class 3 inspection criteria with zero anomaly flags.",
        root_cause: "Nominal Line Operation",
        corrective_actions: [
          "Continue standard production throughput.",
          "Maintain scheduled solder bath temperature logging."
        ],
        manual_verification: "Standard random lot sampling (1 in 50 boards).",
        estimated_downtime: "0 mins"
      },
      is_demo: true
    },
    {
      inspection_id: "PCB-2026-087",
      timestamp: "2026-11-10T13:58:22Z",
      batch_number: "SMT-2026-088B",
      status: "REVIEW",
      status_reason: "Potential Spurious Copper anomaly identified with moderate confidence (68.4%). Human QC review required.",
      original_image: "https://lh3.googleusercontent.com/aida-public/AB6AXuCZs0MJzgzJ5Yzpfz5NHkS07lvPptu4x7IGy99wNIHdmhYwqLDt2kXrXxo_5bmLEbXuzmOWNoNdL-1KYblRU_lnxxnrnQvPEXA5XjhAO4ePCXe0GqNXdsDp87sdYAiSE5Vl4-pWC53vPNMpTPCCmaakVM6bfbpievGQvX3_v1M845fgoXYBB0hVXmarIEnozWD_QxUVPcsJyB0L9sOTYTnMp4ngiq5u2pQTTxL0VjH-",
      annotated_image: "https://lh3.googleusercontent.com/aida-public/AB6AXuCZs0MJzgzJ5Yzpfz5NHkS07lvPptu4x7IGy99wNIHdmhYwqLDt2kXrXxo_5bmLEbXuzmOWNoNdL-1KYblRU_lnxxnrnQvPEXA5XjhAO4ePCXe0GqNXdsDp87sdYAiSE5Vl4-pWC53vPNMpTPCCmaakVM6bfbpievGQvX3_v1M845fgoXYBB0hVXmarIEnozWD_QxUVPcsJyB0L9sOTYTnMp4ngiq5u2pQTTxL0VjH-",
      defects: [
        {
          defect_id: "DF-087-01",
          class_name: "spurious_copper",
          display_name: "Spurious Copper",
          confidence: 0.68,
          severity: "MAJOR",
          ref_des: "Ground Plane B",
          bbox: { x1: 45, y1: 65, x2: 58, y2: 78 }
        }
      ],
      recommendation: {
        summary: "Potential micro-etch residue detected near ground plane perimeter. Optical reflection may be causing ambiguity.",
        root_cause: "Etch Bath Chemical Balance / Optical Glare",
        corrective_actions: [
          "Perform manual microscopic verification (10x zoom) at coordinate X:450, Y:650.",
          "If confirmed, clean panel with deionized wash cycle.",
          "Check illumination polarization ring angle on camera rig."
        ],
        manual_verification: "Manual sign-off required before advancing to conformal coating.",
        estimated_downtime: "~1.5 mins"
      },
      is_demo: true
    }
  ];

  let inMemoryInspections = [...INITIAL_DEMO_INSPECTIONS];

  class APIService {
    constructor() {
      this.baseUrl = API_CONFIG.BASE_URL;
      this.initStorage();
    }

    initStorage() {
      try {
        if (!localStorage.getItem(API_CONFIG.STORAGE_KEY_INSPECTIONS)) {
          localStorage.setItem(API_CONFIG.STORAGE_KEY_INSPECTIONS, JSON.stringify(INITIAL_DEMO_INSPECTIONS));
        }
      } catch (e) {
        // Fallback to in-memory if localStorage is restricted
      }
    }

    async checkHealth() {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 2000);
        
        const res = await fetch(`${this.baseUrl}/health`, { 
          signal: controller.signal 
        });
        clearTimeout(timeoutId);

        if (res.ok) {
          const data = await res.json();
          return { online: true, details: data };
        }
      } catch (e) {
        // Backend offline
      }
      return { 
        online: false, 
        details: { 
          yolo: 'Not Connected', 
          llama: 'Not Connected', 
          pytorch: 'Not Connected', 
          backend: 'Offline (Using Demo Engine)' 
        } 
      };
    }

    async inspectPCB(file) {
      try {
        const formData = new FormData();
        formData.append('file', file);

        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), API_CONFIG.TIMEOUT_MS);

        const response = await fetch(`${this.baseUrl}/inspect`, {
          method: 'POST',
          body: formData,
          signal: controller.signal
        });
        clearTimeout(timeoutId);

        if (response.ok) {
          const result = await response.json();
          this.saveInspection(result);
          return { success: true, is_demo: false, data: result };
        }
      } catch (error) {
        console.warn('Real backend /inspect unavailable, switching to Demo Inspection Engine:', error.message);
      }

      const demoResult = await this.generateDemoInspection(file);
      this.saveInspection(demoResult);
      return { success: true, is_demo: true, data: demoResult };
    }

    async generateDemoInspection(file) {
      const inspectionId = `PCB-2026-${Math.floor(100 + Math.random() * 900)}`;
      const imageUrl = URL.createObjectURL(file);
      
      const hash = (file.name.length + file.size) % 3;
      let status = "PASS";
      let statusReason = "Zero anomalies detected. Meets IPC-A-610 Class 3 specifications.";
      let defects = [];
      let recommendation = {
        summary: "PCB board nominal. SMT placement tolerances and solder wetting verified.",
        root_cause: "Nominal Line Operation",
        corrective_actions: [
          "Maintain standard conveyor velocity.",
          "Check reflow profile temp sensor #2."
        ],
        manual_verification: "Standard batch sampling (1 in 50).",
        estimated_downtime: "0 mins"
      };

      if (hash === 1) {
        status = "FAIL";
        statusReason = "2 critical anomalies identified: Missing Hole and Spur defect detected.";
        defects = [
          {
            defect_id: `DF-${Math.floor(10 + Math.random() * 89)}-01`,
            class_name: "missing_hole",
            display_name: "Missing Hole",
            confidence: 0.94,
            severity: "CRITICAL",
            ref_des: "H3 (Via Pad 12)",
            bbox: { x1: 28, y1: 30, x2: 46, y2: 48 }
          },
          {
            defect_id: `DF-${Math.floor(10 + Math.random() * 89)}-02`,
            class_name: "spur",
            display_name: "Spur",
            confidence: 0.88,
            severity: "MINOR",
            ref_des: "Trace Q2-Drain",
            bbox: { x1: 60, y1: 52, x2: 78, y2: 70 }
          }
        ];
        recommendation = {
          summary: "Via drilling drill wear and copper over-etching identified.",
          root_cause: "Drill Bit Micro-fracture / Etchant Concentration Drift",
          corrective_actions: [
            "Replace CNC drill bit #3 immediately.",
            "Verify chemical titration of copper etchant bath.",
            "Calibrate optical autofocus on line camera."
          ],
          manual_verification: "Microscopic conductivity check of via barrel H3 required.",
          estimated_downtime: "~4.0 mins"
        };
      } else if (hash === 2) {
        status = "REVIEW";
        statusReason = "Mouse bite detected near outer ground edge. Operator confirmation required.";
        defects = [
          {
            defect_id: `DF-${Math.floor(10 + Math.random() * 89)}-01`,
            class_name: "mouse_bite",
            display_name: "Mouse Bite",
            confidence: 0.72,
            severity: "MAJOR",
            ref_des: "Perimeter Edge C",
            bbox: { x1: 40, y1: 58, x2: 55, y2: 72 }
          }
        ];
        recommendation = {
          summary: "Routing breakaway tab residue or slight mechanical nick on ground edge.",
          root_cause: "Depaneling Router Bit Vibration",
          corrective_actions: [
            "Inspect PCB depaneling router spindle balance.",
            "Confirm minimum copper clearance from v-score groove.",
            "Log anomaly in SPC tracking ledger."
          ],
          manual_verification: "Physical caliper measurement of edge clearance (min 0.3mm).",
          estimated_downtime: "~1.5 mins"
        };
      }

      return {
        inspection_id: inspectionId,
        timestamp: new Date().toISOString(),
        batch_number: "SMT-2026-089A",
        status: status,
        status_reason: statusReason,
        original_image: imageUrl,
        annotated_image: imageUrl,
        defects: defects,
        recommendation: recommendation,
        is_demo: true
      };
    }

    saveInspection(inspection) {
      try {
        let list = this.getSavedInspections();
        list = list.filter(item => item.inspection_id !== inspection.inspection_id);
        list.unshift(inspection);
        localStorage.setItem(API_CONFIG.STORAGE_KEY_INSPECTIONS, JSON.stringify(list));
      } catch (e) {
        inMemoryInspections = inMemoryInspections.filter(item => item.inspection_id !== inspection.inspection_id);
        inMemoryInspections.unshift(inspection);
      }
    }

    getSavedInspections() {
      try {
        const raw = localStorage.getItem(API_CONFIG.STORAGE_KEY_INSPECTIONS);
        if (raw) return JSON.parse(raw);
      } catch (e) {
        // Fallback
      }
      return inMemoryInspections;
    }

    getInspectionById(id) {
      const all = this.getSavedInspections();
      return all.find(item => item.inspection_id === id) || null;
    }

    getAnalyticsSummary() {
      const list = this.getSavedInspections();
      const total = list.length;
      const passed = list.filter(i => i.status === 'PASS').length;
      const failed = list.filter(i => i.status === 'FAIL').length;
      const review = list.filter(i => i.status === 'REVIEW').length;
      const fpy = total > 0 ? ((passed / total) * 100).toFixed(1) : "0.0";
      const defectRate = total > 0 ? (((failed + review) / total) * 100).toFixed(1) : "0.0";

      const classCounts = {
        'mouse_bite': 0,
        'spur': 0,
        'missing_hole': 0,
        'short': 0,
        'open_circuit': 0,
        'spurious_copper': 0
      };

      list.forEach(i => {
        if (i.defects && Array.isArray(i.defects)) {
          i.defects.forEach(d => {
            const key = d.class_name ? d.class_name.toLowerCase().replace(/ /g, '_') : '';
            if (classCounts[key] !== undefined) {
              classCounts[key]++;
            }
          });
        }
      });

      return {
        total,
        passed,
        failed,
        review,
        fpy,
        defectRate,
        classCounts,
        recent: list.slice(0, 10)
      };
    }
  }

  const api = new APIService();
  global.PCB_DEFECT_CLASSES = PCB_DEFECT_CLASSES;
  global.api = api;
  global.APIService = APIService;
})(typeof window !== 'undefined' ? window : this);

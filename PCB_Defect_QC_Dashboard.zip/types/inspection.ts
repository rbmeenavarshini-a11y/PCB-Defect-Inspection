/**
 * AOI VisionQC - TypeScript Type Definitions
 * Complete Data Models for PCB Defect Detection & Quality Control
 * Complies with Section 12 of the Quality Control Specification
 */

export type InspectionStatus = 'PASS' | 'FAIL' | 'REVIEW';

export type DefectSeverity = 'CRITICAL' | 'MAJOR' | 'MINOR';

export type PCBDefectType = 
  | 'mouse_bite'
  | 'spur'
  | 'missing_hole'
  | 'short'
  | 'open_circuit'
  | 'spurious_copper';

export interface BoundingBox {
  x1: number;
  y1: number;
  x2: number;
  y2: number;
}

export interface DefectItem {
  defect_id: string;
  class_name: PCBDefectType | string;
  display_name: string;
  confidence: number; // 0.0 to 1.0
  severity: DefectSeverity;
  ref_des?: string;   // Reference designator e.g. "C14", "U3"
  bbox: BoundingBox;
}

export interface AIRecommendation {
  summary: string;
  root_cause: string;
  corrective_actions: string[];
  manual_verification: string;
  estimated_downtime?: string;
}

export interface InspectionResponse {
  inspection_id: string;
  timestamp: string; // ISO 8601
  batch_number: string;
  status: InspectionStatus;
  status_reason: string;
  original_image: string; // URL or base64
  annotated_image: string;
  defects: DefectItem[];
  recommendation: AIRecommendation;
  is_demo?: boolean;
}

export interface AnalyticsSummary {
  total: number;
  passed: number;
  failed: number;
  review: number;
  fpy: number; // First pass yield percentage
  defectRate: number;
  classCounts: Record<PCBDefectType, number>;
  recent: InspectionResponse[];
}

export interface SystemComponentStatus {
  name: string;
  role: string;
  status: 'CONNECTED' | 'DISCONNECTED' | 'NOT_CONFIGURED';
  latency_ms?: number;
  details?: string;
}

export interface SystemDiagnostics {
  components: SystemComponentStatus[];
  cpu_usage_pct: number;
  ram_usage_pct: number;
  gpu_available: boolean;
  gpu_name?: string;
  camera_status: string;
  database_status: string;
  edge_device_status: string;
}
